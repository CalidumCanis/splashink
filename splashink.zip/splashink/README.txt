                     _____splashink_____

Current features:

	Chalk tool
	Colour adjustment
	Line thickness
	Eraser tool

Latest Release:

	-

Upcoming features:

	Line tool
	Rectangle Tool
	Curve Tool
	Ellipse Tool
	Move Tool

Thanks for choosing splashink!